# extra.sh - service.sh se source hota hai (helpers: log w rd screen_off set_setting ; vars: DATA R MX_* MEDIA_TUNE)
# v4.2: touch-calibration / TSP commands / dtune hata diye. mdnie sirf MX_COLOR=1 par.
MD=/sys/class/mdnie/mdnie
wq() { [ -w "$R$1" ] && echo "$2" > "$R$1" 2>/dev/null; }   # quiet write (loop me log spam na ho)
rdn() { timeout 2 head -c 200 "$R$1" 2>/dev/null | tr '\n' ' ' | sed 's/ *$//'; }

mx_setup() {
  for p in $MX_PKGS; do
    pm path "$p" >/dev/null 2>&1 || continue
    # whitelist sirf tab record karo jab pehle se user-whitelisted na ho (revert/uninstall me sirf apni wali hatayenge)
    if ! cmd deviceidle whitelist 2>/dev/null | grep -q "^user,$p,"; then
      cmd deviceidle whitelist "+$p" >/dev/null 2>&1
      grep -qx "$p" "$DATA/mx_idle.list" 2>/dev/null || echo "$p" >> "$DATA/mx_idle.list"
    fi
    cmd appops set "$p" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
    grep -qx "$p" "$DATA/mx_touched.list" 2>/dev/null || echo "$p" >> "$DATA/mx_touched.list"
    am set-standby-bucket "$p" active >/dev/null 2>&1
    log "MX setup: $p (doze-whitelist, bg allow, standby=active)"
    if [ ! -f "$DATA/.mx_compiled_$p" ]; then
      touch "$DATA/.mx_compiled_$p"
      ( if cmd package compile -m speed -f "$p" >/dev/null 2>&1; then log "MX dexopt speed: $p"; else log "MX dexopt FAILED: $p"; fi ) &
    fi
  done
}
mx_alive() { for p in $MX_PKGS; do pidof "$p" >/dev/null 2>&1 && return 0; done; return 1; }
mx_fg() {
  r=$(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity')
  for p in $MX_PKGS; do case "$r" in *" $p/"*) return 0;; esac; done; return 1
}
mdnie_num() {  # "Current mode : Natural" / "2" -> number
  v=$(rdn "$1"); case "$v" in *[Dd]ynamic*) echo 0;; *[Ss]tandard*) echo 1;; *[Nn]atural*) echo 2;; *[Mm]ovie*) echo 3;; *[Aa]uto*) echo 4;; *) echo "$v" | tr -cd '0-9' ;; esac
}
mx_enter() {
  st=1
  if [ "$MX_COLOR" = 1 ] && [ -d "$R$MD" ]; then om=$(mdnie_num "$MD/mode"); log "MX foreground: mdnie mode(orig)=$om -> $MX_MDNIE_MODE, scenario=video"; fi
  ora=$(rd /sys/block/mmcblk0/queue/read_ahead_kb); [ -z "$ora" ] && ora=256
  [ -n "$MX_READAHEAD" ] && w /sys/block/mmcblk0/queue/read_ahead_kb "$MX_READAHEAD"
}
mx_leave() {
  st=0
  if [ "$MX_COLOR" = 1 ] && [ -d "$R$MD" ]; then w "$MD/scenario" 0; [ -n "$om" ] && w "$MD/mode" "$om"; fi
  w /sys/block/mmcblk0/queue/read_ahead_kb "$ora"
  log "MX background: display/io restore"
}
mx_loop() {
  st=0; om=""; ora=256
  while :; do
    if ! mx_alive; then
      [ "$st" = 1 ] && mx_leave
      sleep 20; continue
    fi
    if ! screen_off && mx_fg; then
      [ "$st" = 0 ] && mx_enter
      [ "$MX_COLOR" = 1 ] && [ -d "$R$MD" ] && { wq "$MD/mode" "$MX_MDNIE_MODE"; wq "$MD/scenario" 1; }
    else
      [ "$st" = 1 ] && mx_leave
    fi
    sleep 4
  done
}
stage_media() {
  [ "$MEDIA_TUNE" = 1 ] || return 0
  mx_setup
  # loop sirf tab jab display/io wala feature ON ho (default OFF => kuch bhi background me nahi chalta)
  if [ -z "$A205F_TEST" ] && { [ "$MX_COLOR" = 1 ] || [ -n "$MX_READAHEAD" ]; }; then
    ( mx_loop ) >/dev/null 2>&1 &
  fi
}

# A205F Ultimate Merged v5.2
SM-A205F (Galaxy A20) Android 11 / One UI 3.1 + Magisk. DeepDebloat v1.2 + Ultimate v4.2 merged.
Config: /data/adb/a205f_ultimate/config.conf   Log: log.txt
Tool: su -c "sh /data/adb/a205f_ultimate/ctl.sh status|log|diag|set K V|keep X|restore <pkg|all>|rearm|revert"
v5.2: "Disable HW overlays" + "Force 4x MSAA" default OFF (FPS/battery/GPU load bachane ke liye; install par force OFF). ON karne ke liye: ctl.sh set DEV_NO_HWOVERLAY 1 / DEV_FORCE_MSAA 1 + reboot.

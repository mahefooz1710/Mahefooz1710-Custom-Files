#!/system/bin/sh
# Magisk Action button: status; agar guard ne bypass kiya tha to re-arm
D=/data/adb/a205f_ultimate
sh "$D/ctl.sh" status 2>/dev/null || echo "ctl.sh nahi mila - ek baar reboot karo"
if [ -f "$D/off" ]; then sh "$D/ctl.sh" rearm; fi

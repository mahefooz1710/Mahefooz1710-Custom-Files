#!/system/bin/sh
# A205F Ultimate v5.0 - service.sh (boot complete ke baad)
# Har risky kaam ek "stage": log me ">> X" / "<< X ok". Hang hua to agle boot me post-fs-data 2 fail ke baad skip kar deta hai.
MODDIR=${0%/*}; [ "$MODDIR" = "$0" ] && MODDIR=.
DATA="${A205F_DATA:-/data/adb/a205f_ultimate}"
R="${A205F_ROOT:-}"
L="$MODDIR/lists"
CONF="$DATA/config.conf"; LOG="$DATA/log.txt"
mkdir -p "$DATA"
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && : > "$LOG"
log() { echo "[$(date '+%m-%d %H:%M:%S')] $*" >> "$LOG"; }

# ---- defaults (config.conf override karega) ----
SYSTEMLESS_REMOVE=1; FREEZE_APPS=1; FREEZE_COMPONENTS=1; STOP_SERVICES=1
DEL_PRINT=1; DEL_WELLBEING=1; DEL_OTA=1; DEL_SAMSUNG=1; DEL_3P=1; DEL_GOOGLE=1; DEL_GOOGLE_APPS=1
DEL_GOOGLE_AGGR=1; DEL_AGGRESSIVE=1; DEL_LIVEWP=1; DEL_FONTS=1; EXTRA_DEL=""; KEEP_PACKAGES=""
TRIM_SOUNDS=1; SOUND_KEEP=""
VM_TWEAKS=1; IO_TWEAKS=1; READ_AHEAD_KB=256; CPU_TWEAKS=1; ZRAM_MB=0; MIN_FREE_KB=16384
NET_TWEAKS=1; NET_HANG_FIX=1; PRIVATE_DNS=""
BATTERY_TWEAKS=1; DOZE_TWEAK=1; PRIVACY_TWEAKS=1; TOUCH_TWEAKS=1; UHQ_AUDIO=1
ANIM_SCALE="0"; DEV_NO_HWOVERLAY=0; DEV_FORCE_MSAA=0
MAINT_HOURS=72; CLEAN_JUNK=1; TRIM_FS=1; IDLE_MAINT=1; COMPACT_MEM=1; DEXOPT=1; DEXOPT_ALL_ONCE=1
MEDIA_TUNE=1; MX_PKGS="com.mxtech.videoplayer.ad com.mxtech.videoplayer.pro"
MX_COLOR=0; MX_MDNIE_MODE=2; MX_READAHEAD=""
if [ -f "$CONF" ]; then
  if sh -n "$CONF" 2>/dev/null; then . "$CONF"
  else log "config.conf me syntax error -> defaults use ho rahe hain (file theek karo)"; fi
fi
case "$MAINT_HOURS" in ''|*[!0-9]*) MAINT_HOURS=72 ;; esac
case "$READ_AHEAD_KB" in ''|*[!0-9]*) READ_AHEAD_KB=256 ;; esac

# ---- boot complete wait ----
if [ -z "$A205F_TEST" ]; then
  n=0
  while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; n=$((n+1)); [ "$n" -gt 120 ] && exit 0; done
  sleep 45
fi
sp=$(pidof system_server)

# ================= helpers =================
touch "$DATA/orig.txt" "$DATA/removed.list" "$DATA/keep.list" "$DATA/skip.list" "$DATA/frozen" "$DATA/frozen_comp"
rl() { sed 's/[[:space:]]*#.*//;s/^[[:space:]]*//;s/[[:space:]]*$//;/^$/d' "$1" 2>/dev/null; }
rd() { cat "$R$1" 2>/dev/null; }
w() { [ -w "$R$1" ] || return 0; echo "$2" > "$R$1" 2>/dev/null && log "sys $1=$2"; }
set_setting() {   # ns key val  (original ek baar orig.txt me)
  ns=$1; key=$2; val=$3
  if ! grep -q "^$ns $key " "$DATA/orig.txt" 2>/dev/null; then
    cur=$(settings get "$ns" "$key" 2>/dev/null); echo "$ns $key $cur" >> "$DATA/orig.txt"
  fi
  settings put "$ns" "$key" "$val" 2>/dev/null && log "setting $ns/$key=$val"
}
restore_setting() {
  ns=$1; key=$2
  line=$(grep "^$ns $key " "$DATA/orig.txt" 2>/dev/null | head -n 1); [ -z "$line" ] && return 0
  v=${line#"$ns $key "}
  if [ "$v" = "null" ] || [ -z "$v" ]; then settings delete "$ns" "$key" 2>/dev/null; else settings put "$ns" "$key" "$v" 2>/dev/null; fi
  grep -v "^$ns $key " "$DATA/orig.txt" > "$DATA/orig.tmp" 2>/dev/null; mv -f "$DATA/orig.tmp" "$DATA/orig.txt"
  log "restored $ns/$key=$v"
}
screen_off() { dumpsys power 2>/dev/null | grep -q 'mWakefulness=Asleep'; }
charging()   { dumpsys battery 2>/dev/null | grep -qE '(AC|USB|Wireless) powered: true'; }
skipped()     { grep -qx "$1" "$DATA/skip.list" 2>/dev/null; }
stage_begin() { echo "$1" > "$DATA/.stage"; sync; log ">> stage $1"; }
stage_end()   { : > "$DATA/.stage"; rm -f "$DATA/.fail_$1"; log "<< stage $1 ok"; }
run_stage()   { if skipped "$1"; then log "stage $1 QUARANTINED -> skip"; return 0; fi; stage_begin "$1"; "$2"; stage_end "$1"; }

# never.tmp = never.list + keep.list + KEEP_PACKAGES
{ rl "$L/never.list"; rl "$DATA/keep.list"; for k in $KEEP_PACKAGES; do echo "$k"; done; } > "$DATA/never.tmp"
never_has() { grep -qxF "$1" "$DATA/never.tmp" 2>/dev/null; }
is_protected() {   # delete ke liye: never.list + broad patterns
  never_has "$1" && return 0
  case "$1" in
    android|com.android.systemui|com.android.settings|com.android.phone|\
    com.android.server.telecom|com.android.providers.*|com.android.shell|\
    com.android.inputmethod*|com.android.bluetooth|com.android.nfc|\
    com.android.networkstack*|com.android.permissioncontroller|\
    com.android.packageinstaller|com.google.android.packageinstaller|\
    com.android.vpndialogs|com.android.keychain|com.android.wallpapercropper|\
    com.sec.android.app.launcher|com.sec.android.app.camera|\
    com.sec.android.inputmethod|com.samsung.android.honeyboard|\
    com.samsung.android.dialer|com.samsung.android.incallui|\
    com.samsung.android.messaging|com.samsung.android.contacts|\
    com.samsung.android.lool|com.sec.android.sdhms|\
    com.samsung.android.knox*|com.knox.*|com.samsung.android.authfw|\
    com.samsung.android.biometrics*|com.samsung.android.provider.*|\
    com.samsung.android.networkstack*|\
    com.samsung.android.wallpaper.res|com.samsung.android.app.dressroom|\
    com.samsung.android.app.aodservice|\
    com.monotype.android.font.foundation|com.monotype.android.font.samsungone|\
    com.google.android.gms|com.google.android.gsf|com.android.vending|\
    com.google.android.webview|com.android.webview|com.google.android.trichromelibrary*|\
    com.google.android.inputmethod*|com.google.android.networkstack*|\
    com.google.android.permissioncontroller|com.google.android.ext.services|\
    com.google.android.captiveportallogin|com.android.captiveportallogin|\
    com.android.cellbroadcast*|com.google.android.cellbroadcast*|\
    com.android.carrierconfig|com.android.stk|com.android.stk2|com.android.emergency|\
    com.samsung.android.app.telephonyui|com.samsung.android.smartcallprovider|\
    com.sec.imsservice|com.sec.epdg|com.samsung.android.ims|com.samsung.android.cidmanager)
      return 0 ;;
  esac
  return 1
}

# ================= STAGE: KERNEL =================
stage_kernel() {
  if [ "$VM_TWEAKS" = 1 ]; then
    if grep -q zram "$R/proc/swaps" 2>/dev/null; then w /proc/sys/vm/swappiness 100; w /proc/sys/vm/page-cluster 0
    else log "zram swap nahi mila - swappiness untouched"; fi
    w /proc/sys/vm/vfs_cache_pressure 80
    w /proc/sys/vm/dirty_background_bytes 33554432
    w /proc/sys/vm/dirty_bytes 134217728
    w /proc/sys/vm/dirty_expire_centisecs 1500
    w /proc/sys/vm/dirty_writeback_centisecs 500
    w /proc/sys/vm/oom_dump_tasks 0
    w /proc/sys/vm/watermark_scale_factor 30
  fi
  if [ "$IO_TWEAKS" = 1 ]; then
    Q=/sys/block/mmcblk0/queue
    log "eMMC scheduler: $(rd $Q/scheduler)"
    w $Q/read_ahead_kb "$READ_AHEAD_KB"; w $Q/iostats 0; w $Q/add_random 0
    cur=$(rd $Q/nr_requests); [ -n "$cur" ] && [ "$cur" -lt 128 ] 2>/dev/null && w $Q/nr_requests 128
    w $Q/iosched/slice_idle 0; w $Q/iosched/group_idle 0; w $Q/iosched/low_latency 1
  fi
  if [ "$CPU_TWEAKS" = 1 ]; then
    for g in "$R"/sys/devices/system/cpu/cpufreq/policy*/interactive; do
      [ -d "$g" ] || continue; p=${g#"$R"}
      c=$(rd "$p/go_hispeed_load"); [ -n "$c" ] && [ "$c" -gt 85 ] 2>/dev/null && w "$p/go_hispeed_load" 85
      c=$(rd "$p/timer_slack"); [ -n "$c" ] && [ "$c" -gt 40000 ] 2>/dev/null && w "$p/timer_slack" 40000
    done
  fi
}

# ================= STAGE: NET =================
stage_net() {
  if [ "$NET_TWEAKS" = 1 ]; then
    w /proc/sys/net/ipv4/tcp_slow_start_after_idle 0
    w /proc/sys/net/ipv4/tcp_fastopen 3
    w /proc/sys/net/ipv4/tcp_no_metrics_save 1
    w /proc/sys/net/ipv4/tcp_mtu_probing 1
    w /proc/sys/net/core/rmem_max 4194304
    w /proc/sys/net/core/wmem_max 4194304
    AVAIL=" $(rd /proc/sys/net/ipv4/tcp_available_congestion_control) "
    for c in bbr westwood; do case "$AVAIL" in *" $c "*) w /proc/sys/net/ipv4/tcp_congestion_control "$c"; break ;; esac; done
  fi
  if [ "$NET_HANG_FIX" = 1 ]; then
    cur=$(rd /proc/sys/vm/min_free_kbytes)
    [ -n "$cur" ] && [ "$cur" -lt "${MIN_FREE_KB:-16384}" ] 2>/dev/null && w /proc/sys/vm/min_free_kbytes "${MIN_FREE_KB:-16384}"
    w /proc/sys/net/ipv4/tcp_rmem "4096 87380 2097152"
    w /proc/sys/net/ipv4/tcp_wmem "4096 65536 2097152"
    w /proc/sys/net/core/netdev_max_backlog 2000
  fi
}

# ================= STAGE: ZRAM (opt-in) =================
zram_resize() {
  want=$1; z="$R/sys/block/zram0"; ZDEV="${A205F_ZDEV:-/dev/block/zram0}"
  [ -d "$z" ] || { log "zram0 nahi mila - resize skip"; return 1; }
  cur=$(cat "$z/disksize" 2>/dev/null); [ "$cur" = "$want" ] && return 0
  used=0
  while read -r f t sz u pr; do case "$f" in *zram0) used=$u ;; esac; done < "$R/proc/swaps" 2>/dev/null
  avail=$(grep MemAvailable "$R/proc/meminfo" 2>/dev/null | tr -s ' ' | cut -d' ' -f2); [ -z "$avail" ] && avail=0
  if [ "$avail" -lt $((used + 262144)) ]; then log "zram resize skip: RAM free kam"; return 1; fi
  [ -f "$DATA/zram.orig" ] || echo "$cur" > "$DATA/zram.orig"
  if swapoff "$ZDEV" >/dev/null 2>&1; then
    echo 1 > "$z/reset" 2>/dev/null
    if echo "$want" > "$z/disksize" 2>/dev/null && mkswap "$ZDEV" >/dev/null 2>&1 && swapon "$ZDEV" >/dev/null 2>&1; then
      log "zram resized: $cur -> $want"; return 0
    fi
    echo 1 > "$z/reset" 2>/dev/null; echo "$cur" > "$z/disksize" 2>/dev/null
    mkswap "$ZDEV" >/dev/null 2>&1; swapon "$ZDEV" >/dev/null 2>&1; log "zram resize FAILED -> rollback $cur"
  else log "zram swapoff fail - skip"; fi
  return 1
}
stage_zram() {
  if [ "${ZRAM_MB:-0}" -gt 0 ] 2>/dev/null; then
    [ "$ZRAM_MB" -gt 2560 ] && ZRAM_MB=2560
    zram_resize $((ZRAM_MB * 1048576))
  elif [ -f "$DATA/zram.orig" ]; then
    zram_resize "$(cat "$DATA/zram.orig")" && rm -f "$DATA/zram.orig"
  fi
}

# ================= STAGE: SETTINGS (battery / net / privacy / animations) =================
stage_settings() {
  if [ -n "$ANIM_SCALE" ] && [ -z "$(echo "$ANIM_SCALE" | tr -d '0-9.')" ]; then
    set_setting global window_animation_scale "$ANIM_SCALE"
    set_setting global transition_animation_scale "$ANIM_SCALE"
    set_setting global animator_duration_scale "$ANIM_SCALE"
  else for k in window_animation_scale transition_animation_scale animator_duration_scale; do restore_setting global $k; done; fi
  if [ "$TOUCH_TWEAKS" = 1 ]; then set_setting secure long_press_timeout 300; else restore_setting secure long_press_timeout; fi
  if [ "$BATTERY_TWEAKS" = 1 ]; then
    set_setting global wifi_wakeup_enabled 0
    set_setting global wifi_networks_available_notification_on 0
    set_setting global ble_scan_always_enabled 0
    set_setting global wifi_scan_always_enabled 0
    set_setting global app_standby_enabled 1
    set_setting global adaptive_battery_management_enabled 1
    set_setting global app_auto_restriction_enabled 1
  else for k in wifi_wakeup_enabled wifi_networks_available_notification_on ble_scan_always_enabled wifi_scan_always_enabled app_standby_enabled adaptive_battery_management_enabled app_auto_restriction_enabled; do restore_setting global $k; done; fi
  if [ "$DOZE_TWEAK" = 1 ]; then set_setting global device_idle_constants "inactive_to=60000,motion_inactive_to=60000,idle_after_inactive_to=60000,sensing_to=0,locating_to=0"
  else restore_setting global device_idle_constants; fi
  if [ "$DEL_OTA" = 1 ]; then set_setting global ota_disable_automatic_update 1; else restore_setting global ota_disable_automatic_update; fi
  if [ "$NET_TWEAKS" = 1 ]; then set_setting global tcp_default_init_rwnd 60; else restore_setting global tcp_default_init_rwnd; fi
  if [ "$NET_HANG_FIX" = 1 ]; then
    set_setting global wifi_watchdog_poor_network_test_enabled 0
    set_setting global wifi_verbose_logging_enabled 0
  else restore_setting global wifi_watchdog_poor_network_test_enabled; restore_setting global wifi_verbose_logging_enabled; fi
  if [ "$PRIVACY_TWEAKS" = 1 ]; then
    set_setting system send_security_reports 0
    set_setting system samsung_errorlog_agree 0
    set_setting global enable_automatic_system_server_heap_dumps 0
    set_setting global activity_starts_logging_enabled 0
    set_setting global network_recommendations_enabled 0
  else
    restore_setting system send_security_reports; restore_setting system samsung_errorlog_agree
    restore_setting global enable_automatic_system_server_heap_dumps; restore_setting global activity_starts_logging_enabled
    restore_setting global network_recommendations_enabled
  fi
  if [ "$UHQ_AUDIO" = 1 ]; then set_setting system k2hd_effect 1; else restore_setting system k2hd_effect; fi
  if [ -n "$PRIVATE_DNS" ]; then
    set_setting global private_dns_specifier "$PRIVATE_DNS"; set_setting global private_dns_mode hostname
    sleep 6
    if ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1 && ! ping -c 1 -W 4 google.com >/dev/null 2>&1; then
      restore_setting global private_dns_specifier; restore_setting global private_dns_mode
      log "PRIVATE_DNS $PRIVATE_DNS fail -> rollback"
    fi
  else restore_setting global private_dns_specifier; restore_setting global private_dns_mode; fi
}

# ================= STAGE: DEVOPTS (har boot dobara apply) =================
apply_overlay_off() { service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1 && log "dev: HW overlays DISABLED (SF pid $(pidof surfaceflinger))"; }
stage_devopts() {
  [ "$DEV_FORCE_MSAA" = 1 ] && { setprop debug.egl.force_msaa true 2>/dev/null; log "dev: force 4x MSAA ON"; }
  [ "$DEV_NO_HWOVERLAY" = 1 ] && apply_overlay_off
  return 0
}

# ================= STAGE: FREEZE =================
reconcile_frozen() {   # jo ab protected hain (never/keep) unhe unfreeze
  [ -s "$DATA/frozen" ] || return 0
  : > "$DATA/frozen.keep"
  while read -r p; do
    [ -n "$p" ] || continue
    if never_has "$p"; then pm enable --user 0 "$p" >/dev/null 2>&1; log "unfroze (protected): $p"
    else echo "$p" >> "$DATA/frozen.keep"; fi
  done < "$DATA/frozen"
  mv -f "$DATA/frozen.keep" "$DATA/frozen"
}
stage_freeze() {
  en=$(pm list packages -e --user 0 2>/dev/null)
  if [ "${#en}" -lt 300 ]; then log "pm list khali/chhoti (pm ready nahi?) -> freeze skip"; return 0; fi
  reconcile_frozen
  if [ "$FREEZE_APPS" = 1 ]; then
    : > "$DATA/frozen.new"; k=0
    for p in $(rl "$L/freeze.list"); do
      never_has "$p" && continue
      echo "$en" | grep -qxF "package:$p" || continue
      if pm disable-user --user 0 "$p" >/dev/null 2>&1; then echo "$p" >> "$DATA/frozen.new"; am force-stop "$p" 2>/dev/null; k=$((k+1)); log "frozen: $p"; fi
    done
    cat "$DATA/frozen.new" "$DATA/frozen" 2>/dev/null | sort -u > "$DATA/frozen.tmp"; mv -f "$DATA/frozen.tmp" "$DATA/frozen"; rm -f "$DATA/frozen.new"
    log "freeze: now=$k total=$(wc -l < "$DATA/frozen")"
  fi
  if [ "$FREEZE_COMPONENTS" = 1 ]; then
    for c in $(rl "$L/components.list"); do
      pm disable --user 0 "$c" >/dev/null 2>&1 && echo "$c" >> "$DATA/frozen_comp"
    done
    sort -u "$DATA/frozen_comp" -o "$DATA/frozen_comp"
  fi
  if [ "$STOP_SERVICES" = 1 ]; then
    for s in $(rl "$L/stop.list"); do [ "$(getprop init.svc.$s)" = running ] && stop "$s"; done
  fi
  pm trim-caches 999999999999 >/dev/null 2>&1
  sync; w /proc/sys/vm/drop_caches 3
}

# ================= STAGE: DEBLOAT (pm uninstall --user 0) =================
del_pkg() {
  p=$1; g=$2
  if is_protected "$p"; then log "SKIP protected: $p"; return 0; fi
  case "$INST" in *" $p "*) ;; *) return 0 ;; esac
  [ "$g" = GOOGLE ] || [ "$g" = GOOGLEAPPS ] || [ "$g" = GOOGLEAGGR ] && pm uninstall-system-updates "$p" >/dev/null 2>&1
  if pm uninstall --user 0 "$p" >/dev/null 2>&1; then
    log "deleted: $p"; grep -qx "$p" "$DATA/removed.list" 2>/dev/null || echo "$p" >> "$DATA/removed.list"
  else log "FAILED delete: $p"; fi
}
restore_removed() {   # quarantine/bypass: delete kiye apps wapas (ek baar)
  [ -f "$DATA/.restored" ] && return 0
  [ -s "$DATA/removed.list" ] || return 0
  log "restoring deleted apps"
  while read -r p; do [ -n "$p" ] && pm install-existing --user 0 "$p" >/dev/null 2>&1; done < "$DATA/removed.list"
  touch "$DATA/.restored"
}
stage_debloat() {
  [ -f "$L/packages.txt" ] || return 0
  INST=" $(pm list packages --user 0 2>/dev/null | sed 's/^package://' | tr '\n' ' ') "
  if [ "${#INST}" -lt 300 ]; then log "pm list khali/chhoti -> debloat skip"; return 0; fi
  while IFS=: read -r grp pkg; do
    case "$grp" in ''|\#*) continue ;; esac
    [ -z "$pkg" ] && continue
    want=0
    case "$grp" in
      PRINT) [ "$DEL_PRINT" = 1 ] && want=1 ;;       LIVEWP) [ "$DEL_LIVEWP" = 1 ] && want=1 ;;
      FONTS) [ "$DEL_FONTS" = 1 ] && want=1 ;;       WELLBEING) [ "$DEL_WELLBEING" = 1 ] && want=1 ;;
      OTA) [ "$DEL_OTA" = 1 ] && want=1 ;;           SAMSUNG) [ "$DEL_SAMSUNG" = 1 ] && want=1 ;;
      3P) [ "$DEL_3P" = 1 ] && want=1 ;;             GOOGLE) [ "$DEL_GOOGLE" = 1 ] && want=1 ;;
      GOOGLEAPPS) [ "$DEL_GOOGLE_APPS" = 1 ] && want=1 ;;
      GOOGLEAGGR) [ "$DEL_GOOGLE_AGGR" = 1 ] && want=1 ;;
      AGGRESSIVE) [ "$DEL_AGGRESSIVE" = 1 ] && want=1 ;;
    esac
    [ "$want" = 1 ] && del_pkg "$pkg" "$grp"
  done < "$L/packages.txt"
  for p in $EXTRA_DEL; do del_pkg "$p" EXTRA; done
}

# ================= STAGE: SOUNDS (current selections note karo; trim agle boot se) =================
sound_path() {   # setting value -> file path
  v=${1%%\?*}
  case "$v" in
    ''|null) return 1 ;;
    /*) echo "$v"; return 0 ;;
    file://*) echo "${v#file://}"; return 0 ;;
    content://media/*/audio/media/*)
      id=${v##*/}; case "$id" in ''|*[!0-9]*) return 1 ;; esac
      for vol in internal external; do
        out=$(content query --uri "content://media/$vol/audio/media/$id" --projection _data 2>/dev/null | sed -n 's/.*_data=\(.*\)$/\1/p' | head -n 1)
        [ -n "$out" ] && { echo "$out"; return 0; }
      done ;;
  esac
  return 1
}
stage_sounds() {
  [ "$TRIM_SOUNDS" = 1 ] || { rm -f "$DATA/sounds_ok"; return 0; }
  : > "$DATA/sounds_keep.new"; ok=1
  for key in ringtone notification_sound alarm_alert ringtone_2 notification_sound_2; do
    v=$(settings get system "$key" 2>/dev/null)
    if pth=$(sound_path "$v"); then echo "$pth" >> "$DATA/sounds_keep.new"
    else case "$key" in *_2) ;; *) ok=0; log "sounds: $key resolve nahi hua ($v)" ;; esac; fi
  done
  if [ "$ok" = 1 ] && [ -s "$DATA/sounds_keep.new" ]; then
    mv -f "$DATA/sounds_keep.new" "$DATA/sounds_keep"; touch "$DATA/sounds_ok"; log "sounds: selections saved ($(wc -l < "$DATA/sounds_keep"))"
  else rm -f "$DATA/sounds_keep.new" "$DATA/sounds_ok"; log "sounds: trim OFF (selection confirm nahi)"; fi
}

# ================= STAGE: MEDIA (MX Player) =================
if [ -f "$MODDIR/extra.sh" ]; then . "$MODDIR/extra.sh"; fi

# ================= maintenance =================
junk_clean() {
  rm -rf /data/tombstones/* /data/anr/* /data/system/dropbox/* 2>/dev/null
  find /data/log -type f -mtime +3 -exec rm -f {} + 2>/dev/null
  pm trim-caches 128G >/dev/null 2>&1
}
do_trim() { for m in /data /cache; do fstrim "$m" >/dev/null 2>&1 && log "fstrim $m ok"; done; }
maint_tick() {
  screen_off || return 0
  now=$(date +%s); last=$(cat "$DATA/.last_clean" 2>/dev/null); [ -z "$last" ] && last=0
  if [ $((now - last)) -gt $((MAINT_HOURS * 3600)) ]; then
    [ "$CLEAN_JUNK" = 1 ] && { junk_clean; log "junk clean + cache trim done"; }
    [ "$TRIM_FS" = 1 ] && do_trim
    [ "$COMPACT_MEM" = 1 ] && w /proc/sys/vm/compact_memory 1
    if [ "$IDLE_MAINT" = 1 ] && charging; then ( sm idle-maint run >/dev/null 2>&1 & ); log "sm idle-maint run"; fi
    echo "$now" > "$DATA/.last_clean"
  fi
  if [ "$DEXOPT_ALL_ONCE" = 1 ] && [ ! -f "$DATA/.dexopt_all" ] && charging; then
    touch "$DATA/.dexopt_all"; log "one-time compile -a speed-profile start"
    cmd package compile -m speed-profile -a >/dev/null 2>&1; log "one-time compile done"
  fi
  ld=$(cat "$DATA/.last_dexopt" 2>/dev/null); [ -z "$ld" ] && ld=0
  if [ "$DEXOPT" = 1 ] && [ $((now - ld)) -gt 604800 ] && charging; then
    echo "$now" > "$DATA/.last_dexopt"; cmd package bg-dexopt-job >/dev/null 2>&1 && log "bg-dexopt-job done"
  fi
}

# ================= RUN =================
log "===== boot OK, A205F Ultimate v5.0 start ====="
if [ -f "$DATA/off" ]; then
  log "BYPASS: sab unfreeze + deleted apps wapas"
  while ! pm path android >/dev/null 2>&1; do sleep 2; done
  for p in $(cat "$DATA/frozen" 2>/dev/null); do pm enable --user 0 "$p" >/dev/null 2>&1; done
  for c in $(cat "$DATA/frozen_comp" 2>/dev/null); do pm enable --user 0 "$c" >/dev/null 2>&1; done
  : > "$DATA/frozen"; : > "$DATA/frozen_comp"
  restore_removed
  exit 0
fi
skipped DEBLOAT && restore_removed
run_stage KERNEL   stage_kernel
run_stage NET      stage_net
run_stage ZRAM     stage_zram
run_stage SETTINGS stage_settings
run_stage DEVOPTS  stage_devopts
run_stage FREEZE   stage_freeze
run_stage DEBLOAT  stage_debloat
run_stage SOUNDS   stage_sounds
run_stage MEDIA    stage_media

# ---- device info ----
{
  echo "== model: $(getprop ro.product.model)  build: $(getprop ro.build.display.id)"
  echo "== /data fs";  grep -E ' /data | /cache ' "$R/proc/mounts"
  echo "== /data free"; df -h /data 2>/dev/null
  echo "== eMMC queue"; for f in scheduler read_ahead_kb nr_requests; do echo "$f=$(rd /sys/block/mmcblk0/queue/$f)"; done
  echo "== memory"; head -n 3 "$R/proc/meminfo"; cat "$R/proc/swaps" 2>/dev/null
  echo "== vm"; for f in swappiness page-cluster vfs_cache_pressure min_free_kbytes dirty_bytes dirty_background_bytes; do echo "$f=$(rd /proc/sys/vm/$f)"; done
  echo "== tcp"; cat "$R/proc/sys/net/ipv4/tcp_available_congestion_control" "$R/proc/sys/net/ipv4/tcp_congestion_control" 2>/dev/null
} > "$DATA/device_info.txt" 2>&1
pct=$(df /data 2>/dev/null | awk 'NR==2{gsub("%","",$5); print $5}')
[ -n "$pct" ] && [ "$pct" -ge 85 ] 2>/dev/null && log "WARNING: /data ${pct}% bhara hai - hang ka sabse bada kaaran. 20% free rakho."
[ -f "$MODDIR/ctl.sh" ] && cp -f "$MODDIR/ctl.sh" "$DATA/ctl.sh" && chmod 755 "$DATA/ctl.sh"
log "===== done. deleted=$(wc -l < "$DATA/removed.list") frozen=$(wc -l < "$DATA/frozen") ====="

# background: SurfaceFlinger restart par overlay-off dobara + har 2 ghante maintenance
if [ -z "$A205F_TEST" ]; then
  ( sfp=$(pidof surfaceflinger); t=0
    while :; do
      sleep 60; t=$((t+60))
      if [ "$DEV_NO_HWOVERLAY" = 1 ]; then
        cur=$(pidof surfaceflinger); [ -n "$cur" ] && [ "$cur" != "$sfp" ] && { sfp=$cur; sleep 5; apply_overlay_off; }
      fi
      [ "$t" -ge 7200 ] && { t=0; maint_tick; }
    done ) >/dev/null 2>&1 &
  sleep 60
fi
# boot guard reset: system_server same hai = stable boot
if [ "$(pidof system_server)" = "$sp" ]; then echo 0 > "$DATA/boot"; log "stable -> guard reset"; fi
exit 0

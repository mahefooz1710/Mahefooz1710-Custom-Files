#!/system/bin/sh
# a205f ctl: status | log [N] | snap | diag | maint | clean | trim | net | parts | set K V | restore <pkg|all> | keep <pkg|dir> | rearm | revert
D=${A205F_DATA:-/data/adb/a205f_ultimate}; M=${A205F_MOD:-/data/adb/modules/a205f_ultimate}; mkdir -p "$D"
unfreeze_all() {
  for p in $(cat "$D/frozen" 2>/dev/null); do pm enable --user 0 "$p" >/dev/null 2>&1; done
  for c in $(cat "$D/frozen_comp" 2>/dev/null); do pm enable --user 0 "$c" >/dev/null 2>&1; done
  : > "$D/frozen"; : > "$D/frozen_comp"
}
restore_settings() {
  [ -f "$D/orig.txt" ] || return 0
  while read -r ns key rest; do [ -z "$key" ] && continue
    if [ "$rest" = null ] || [ -z "$rest" ]; then settings delete "$ns" "$key" 2>/dev/null; else settings put "$ns" "$key" "$rest" 2>/dev/null; fi
  done < "$D/orig.txt"
  : > "$D/orig.txt"
}
case "$1" in
snap)  F="$D/snap_$(date +%m%d_%H%M%S).txt"
  { echo "== load"; cat /proc/loadavg; echo "== meminfo"; head -n 8 /proc/meminfo; grep -E 'SwapTotal|SwapFree|Dirty|Writeback:' /proc/meminfo
    echo "== swaps"; cat /proc/swaps; echo "== vmstat"; grep -E 'pswpin|pswpout|pgmajfault|allocstall|pgscan_direct|workingset_refault' /proc/vmstat
    echo "== psi"; cat /proc/pressure/memory /proc/pressure/io 2>/dev/null
    echo "== emmc stat"; cat /sys/block/mmcblk0/stat; echo "== top"; top -b -n 1 -m 12 2>/dev/null | head -n 25
    echo "== meminfo top"; dumpsys meminfo 2>/dev/null | sed -n '1,28p'
    echo "== net"; getprop net.dns1; cat /proc/sys/net/ipv4/tcp_congestion_control
    echo "== ping ip"; ping -c 4 -W 2 8.8.8.8 2>&1 | tail -n 3; echo "== ping dns"; ping -c 2 -W 3 google.com 2>&1 | tail -n 3
  } > "$F" 2>&1; echo "saved: $F" ;;
diag)  sh "$0" snap >/dev/null 2>&1; S=$(ls -t "$D"/snap_*.txt 2>/dev/null | head -n 1); F="$D/diag_$(date +%m%d_%H%M%S).txt"
  { cat "$D/device_info.txt" 2>/dev/null; echo; echo "######## SNAP"; cat "$S" 2>/dev/null; echo "######## LOG"; tail -n 150 "$D/log.txt" 2>/dev/null; } > "$F"; echo "saved: $F" ;;
log)   tail -n "${2:-60}" "$D/log.txt" 2>/dev/null ;;
maint) rm -f "$D/.last_clean"; pm trim-caches 128G >/dev/null 2>&1
       rm -rf /data/tombstones/* /data/anr/* /data/system/dropbox/* 2>/dev/null
       for m in /data /cache; do fstrim -v "$m"; done
       echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
       ( sm idle-maint run >/dev/null 2>&1 & ); echo "maintenance chalu" ;;
clean) pm trim-caches 128G; rm -rf /data/tombstones/* /data/anr/* /data/system/dropbox/*; find /data/log -type f -mtime +3 -exec rm -f {} + 2>/dev/null; echo done ;;
trim)  for m in /data /cache; do fstrim -v "$m"; done ;;
parts) df -h /system /vendor /odm /product /data /cache 2>/dev/null; ls -l /dev/block/by-name 2>/dev/null | head -n 40 ;;
net)   echo "== ip"; ping -c 3 -W 2 8.8.8.8 2>&1 | tail -n 2; echo "== dns"; ping -c 2 -W 3 google.com 2>&1 | tail -n 2
       getprop net.dns1; settings get global private_dns_mode; settings get global private_dns_specifier ;;
set)   case "$2" in ''|[!A-Z]*|*[!A-Z0-9_]*) echo "usage: $0 set KEY VALUE (KEY = config.conf naam, jaise ANIM_SCALE)"; exit 1 ;; esac
  case "$3" in *\"*|*\`*|*\$*|*\\*) echo "VALUE me \" \` \$ \\ allowed nahi"; exit 1 ;; esac
  C="$D/config.conf"; v=$(printf '%s' "$3" | sed 's/[|&]/\\&/g')
  if grep -q "^$2=" "$C" 2>/dev/null; then sed -i "s|^$2=.*|$2=\"$v\"|" "$C"; else echo "$2=\"$3\"" >> "$C"; fi
  echo "$2=\"$3\" -> reboot karo" ;;
keep)  [ -z "$2" ] && { echo "usage: $0 keep <pkg|dir-naam>"; exit 1; }
  echo "$2" >> "$D/keep.list"
  # pkg diya ho to lists se uska dir-naam bhi dhoondh ke keep karo (systemless remove ke liye)
  for dn in $(grep -h "#[[:space:]]*$2[[:space:]]*$" "$M/lists/remove.list" "$M/lists/purge.list" 2>/dev/null | awk '{print $1}'); do echo "$dn" >> "$D/keep.list"; echo "dir keep: $dn"; done
  pm enable --user 0 "$2" >/dev/null 2>&1; pm install-existing --user 0 "$2" >/dev/null 2>&1
  echo "keep: $2 -> REBOOT karo (systemless remove wale apps tabhi wapas aate hain)" ;;
restore)
  [ -z "$2" ] && { echo "usage: $0 restore <package|all>"; exit 1; }
  if [ "$2" = all ]; then
    unfreeze_all
    while read -r p; do [ -n "$p" ] && pm install-existing --user 0 "$p" 2>&1 | tail -n 1 && echo "$p" >> "$D/keep.list"; done < "$D/removed.list"
    : > "$D/removed.list"; echo "frozen + deleted sab wapas. (systemless remove wale: keep <pkg> + reboot)"
  else sh "$0" keep "$2"; grep -vx "$2" "$D/removed.list" > "$D/r.tmp" 2>/dev/null; mv -f "$D/r.tmp" "$D/removed.list"; grep -vx "$2" "$D/frozen" > "$D/f.tmp" 2>/dev/null; mv -f "$D/f.tmp" "$D/frozen"; fi ;;
rearm) rm -f "$D/off" "$D/skip.list" "$D"/.fail_* "$D/.restored"; echo 0 > "$D/boot"; echo "re-armed. Reboot karo." ;;
revert) restore_settings; unfreeze_all
  [ -f "$D/mx_idle.list" ] && while read -r p; do [ -n "$p" ] && cmd deviceidle whitelist "-$p" >/dev/null 2>&1; done < "$D/mx_idle.list"
  [ -f "$D/mx_touched.list" ] && while read -r p; do [ -n "$p" ] && cmd appops set "$p" RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1; done < "$D/mx_touched.list"
  while read -r p; do [ -n "$p" ] && pm install-existing --user 0 "$p" >/dev/null 2>&1; done < "$D/removed.list"; : > "$D/removed.list"
  touch "$D/off"; echo "reverted (module bypass ON). Reboot karo; wapas ON: $0 rearm" ;;
*) echo "== boot counter: $(cat "$D/boot" 2>/dev/null) | bypass: $([ -f "$D/off" ] && echo YES || echo no) | deleted: $(wc -l < "$D/removed.list" 2>/dev/null) | frozen: $(wc -l < "$D/frozen" 2>/dev/null) | quarantined: [$(tr '\n' ' ' < "$D/skip.list" 2>/dev/null)]"
   echo "== sound trim: $([ -f "$D/sounds_ok" ] && echo ready || echo 'not ready')  | systemless removed dirs: $(find "$M/system" -name .replace 2>/dev/null | wc -l)"
   grep -E ' /data ' /proc/mounts 2>/dev/null | cut -d' ' -f1-3; df -h /data 2>/dev/null | tail -n 1
   echo "--- log (last 15) ---"; tail -n 15 "$D/log.txt" 2>/dev/null
   echo "usage: $0 status|log [N]|snap|diag|maint|clean|trim|net|parts|set K V|keep X|restore <pkg|all>|rearm|revert" ;;
esac

#!/system/bin/sh
# A205F Ultimate v5.0 - post-fs-data: stage quarantine + boot guard + systemless remove (.replace) + sound whiteouts
MODDIR=${0%/*}; [ "$MODDIR" = "$0" ] && MODDIR=.
D=${A205F_DATA:-/data/adb/a205f_ultimate}; L=$MODDIR/lists; SYSR=${A205F_SYSROOT:-}
mkdir -p "$D"
log() { echo "[$(date '+%m-%d %H:%M:%S')] pfd: $*" >> "$D/log.txt"; }
rl() { sed 's/[[:space:]]*#.*//;s/^[[:space:]]*//;s/[[:space:]]*$//;/^$/d' "$1" 2>/dev/null; }

SYSTEMLESS_REMOVE=1; TRIM_SOUNDS=1; SOUND_KEEP=""; KEEP_PACKAGES=""
[ -f "$D/config.conf" ] && sh -n "$D/config.conf" 2>/dev/null && . "$D/config.conf"

# 1) pichle boot me koi stage shuru hua par khatam nahi hua -> fail count; 2 baar = quarantine
S=$(cat "$D/.stage" 2>/dev/null)
if [ -n "$S" ]; then
  case "$S" in
    *[!A-Z0-9_]*) ;;
    *) n=$(cat "$D/.fail_$S" 2>/dev/null); n=$((${n:-0}+1)); echo "$n" > "$D/.fail_$S"
       log "stage $S adhoora reh gaya (fail #$n)"
       if [ "$n" -ge 2 ]; then grep -qx "$S" "$D/skip.list" 2>/dev/null || echo "$S" >> "$D/skip.list"; log "QUARANTINE: stage $S skip hoga"; fi ;;
  esac
  : > "$D/.stage"
fi

# 2) boot guard: 3 boot stable nahi hue -> bypass (kuch hide nahi hota, service.sh unfreeze karta hai)
n=$(cat "$D/boot" 2>/dev/null); n=$((${n:-0}+1)); echo "$n" > "$D/boot"
rm -rf "$MODDIR/system"
if [ "$n" -ge 3 ] && [ ! -f "$D/off" ]; then touch "$D/off"; log "BOOT-GUARD: n=$n -> BYPASS ON"; fi
[ -f "$D/off" ] && { log "BYPASS active (n=$n)"; exit 0; }

# 3) protected names = never.list + keep.list + KEEP_PACKAGES
NV=$D/never.tmp
{ rl "$L/never.list"; rl "$D/keep.list"; for k in $KEEP_PACKAGES; do echo "$k"; done; } > "$NV"

rep() {   # dir-name -> .replace (systemless remove)
  grep -qxF "$1" "$NV" && return
  for p in /system/app /system/priv-app /system/system_ext/app /system/system_ext/priv-app /system/product/app /system/product/priv-app /product/app /product/priv-app; do
    [ -d "$SYSR$p/$1" ] || continue
    case $p in /product/*) r=/system$p;; *) r=$p;; esac
    mkdir -p "$MODDIR$r/$1" && touch "$MODDIR$r/$1/.replace"
  done
}
if [ "$SYSTEMLESS_REMOVE" = 1 ]; then
  for d in $(rl "$L/remove.list"); do rep "$d"; done
  for d in $(rl "$L/purge.list"); do rep "$d"; done
fi

# 4) ringtone/notification/alarm trim: sirf jab service.sh ne current selections confirm ki hon (sounds_ok)
keep_sound() {   # $1 full path  $2 basename
  grep -qxF "$1" "$D/sounds_keep" 2>/dev/null && return 0
  for k in Over_the_Horizon Whisper Morning_Flower Basic_Bell $SOUND_KEEP; do case "$2" in "$k"*) return 0 ;; esac; done
  return 1
}
trim_sounds() {
  [ "$TRIM_SOUNDS" = 1 ] && [ -f "$D/sounds_ok" ] && [ -s "$D/sounds_keep" ] || return 0
  for sub in ringtones notifications alarms; do
    dir=/system/media/audio/$sub; [ -d "$SYSR$dir" ] || continue
    T=$D/.rm.$sub; : > "$T"; kept=0; all=0
    for f in "$SYSR$dir"/*; do
      [ -f "$f" ] || continue
      all=$((all+1)); b=${f##*/}
      if keep_sound "$dir/$b" "$b"; then kept=$((kept+1)); else echo "$b" >> "$T"; fi
    done
    [ "$all" -ge 8 ] || { rm -f "$T"; continue; }
    while [ "$kept" -lt 4 ] && [ -s "$T" ]; do sed -i '1d' "$T"; kept=$((kept+1)); done   # kam se kam 4 file bachao
    mkdir -p "$MODDIR$dir"; c=0
    while IFS= read -r b; do [ -n "$b" ] && mknod "$MODDIR$dir/$b" c 0 0 2>/dev/null && c=$((c+1)); done < "$T"
    rm -f "$T"; log "sounds $sub: total=$all kept=$kept whiteout=$c"
  done
}
trim_sounds

log "boot n=$n replace=$(find "$MODDIR/system" -name .replace 2>/dev/null | wc -l) sound_wo=$(find "$MODDIR/system/media" -type c 2>/dev/null | wc -l)"
exit 0

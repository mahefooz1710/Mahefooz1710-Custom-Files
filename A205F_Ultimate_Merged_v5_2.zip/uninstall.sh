#!/system/bin/sh
# Module hatne par: next boot me sab wapas (frozen/deleted apps + settings). Boot par pm/settings nahi hote -> one-shot service.d
D=/data/adb/a205f_ultimate
[ -s "$D/removed.list" ] && cp "$D/removed.list" /data/media/0/Download/a205f_removed_apps.txt 2>/dev/null
mkdir -p /data/adb/service.d
cat > /data/adb/service.d/a205f_restore.sh <<'EOS'
#!/system/bin/sh
D=/data/adb/a205f_ultimate
n=0; while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; n=$((n+1)); [ "$n" -gt 120 ] && exit 0; done
while ! pm path android >/dev/null 2>&1; do sleep 2; done
sleep 25
for p in $(cat "$D/frozen" 2>/dev/null); do pm enable --user 0 "$p" >/dev/null 2>&1; done
for c in $(cat "$D/frozen_comp" 2>/dev/null); do pm enable --user 0 "$c" >/dev/null 2>&1; done
for p in $(cat "$D/removed.list" 2>/dev/null); do pm install-existing --user 0 "$p" >/dev/null 2>&1; done
if [ -f "$D/orig.txt" ]; then
  while read -r ns key rest; do [ -z "$key" ] && continue
    if [ "$rest" = null ] || [ -z "$rest" ]; then settings delete "$ns" "$key" 2>/dev/null; else settings put "$ns" "$key" "$rest" 2>/dev/null; fi
  done < "$D/orig.txt"
fi
[ -f "$D/mx_idle.list" ] && while read -r p; do [ -n "$p" ] && cmd deviceidle whitelist "-$p" >/dev/null 2>&1; done < "$D/mx_idle.list"
[ -f "$D/mx_touched.list" ] && while read -r p; do [ -n "$p" ] && cmd appops set "$p" RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1; done < "$D/mx_touched.list"
rm -rf "$D"; rm -f /data/adb/service.d/a205f_restore.sh
EOS
chmod 755 /data/adb/service.d/a205f_restore.sh
exit 0

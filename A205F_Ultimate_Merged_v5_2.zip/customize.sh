# A205F Ultimate v5.0 installer
DATA=/data/adb/a205f_ultimate
M=$(getprop ro.product.model)
[ "${M#SM-A205}" != "$M" ] || abort "! Sirf SM-A205x ke liye (mila: $M)"
[ "$API" = 30 ] || abort "! Android 11 (API 30) chahiye, mila API $API"

ui_print " "
ui_print "=============================="
ui_print "  A205F Ultimate v5.0 (merged)"
ui_print "=============================="
mkdir -p "$DATA"
[ -f "$DATA/config.conf" ] || cp "$MODPATH/config.conf" "$DATA/config.conf"
# upgrade: naye keys jodo, purani values untouched
while IFS= read -r ln; do
  case "$ln" in [A-Z]*=*) k=${ln%%=*}; grep -q "^$k=" "$DATA/config.conf" 2>/dev/null || echo "$ln" >> "$DATA/config.conf" ;; esac
done < "$MODPATH/config.conf"
# DEV_NO_HWOVERLAY + DEV_FORCE_MSAA = default OFF (purani config me 1 ho to bhi OFF; chahiye to ctl.sh set se ON karo)
for k in DEV_NO_HWOVERLAY DEV_FORCE_MSAA; do
  if grep -q "^$k=" "$DATA/config.conf" 2>/dev/null; then sed -i "s/^$k=[^ #]*/$k=0/" "$DATA/config.conf"
  else echo "$k=0" >> "$DATA/config.conf"; fi
done
# fresh start: purana guard/quarantine state saaf
rm -f "$DATA/off" "$DATA/skip.list" "$DATA"/.fail_* "$DATA/.stage" "$DATA/.restored" 2>/dev/null
echo 0 > "$DATA/boot"

# purane modules: disable (dono saath chalne se double-freeze/boot-guard conflict hota)
for old in a205f_deepdebloat a20_optimizer; do
  if [ -d "/data/adb/modules/$old" ]; then
    touch "/data/adb/modules/$old/disable"
    ui_print "- Purana module '$old' DISABLE kiya (baad me hata sakte ho)"
  fi
done
# DeepDebloat ki frozen list import (taaki protected ho chuke pkgs unfreeze ho sakein)
[ -s /data/adb/a205f_dd/frozen ] && [ ! -s "$DATA/frozen" ] && cp /data/adb/a205f_dd/frozen "$DATA/frozen"

set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0644
  for f in post-fs-data.sh service.sh extra.sh uninstall.sh action.sh ctl.sh; do set_perm "$MODPATH/$f" 0 0 0755; done
}
ui_print "- remove.list $(sed 's/[[:space:]]*#.*//;/^[[:space:]]*$/d' $MODPATH/lists/remove.list | wc -l) | purge.list $(sed 's/[[:space:]]*#.*//;/^[[:space:]]*$/d' $MODPATH/lists/purge.list | wc -l) | freeze.list $(sed 's/[[:space:]]*#.*//;/^[[:space:]]*$/d' $MODPATH/lists/freeze.list | wc -l)"
ui_print "- Bootloop guard: 2 fail boot = auto bypass + unfreeze"
ui_print "- Config: $DATA/config.conf  | Log: $DATA/log.txt"
ui_print "- Manual rescue: TWRP/adb me  rm -rf /data/adb/modules/a205f_ultimate"
ui_print "- Ab REBOOT karo. Pehle boot ke ~1 min baad kaam shuru hota hai."

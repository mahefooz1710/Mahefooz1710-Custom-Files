#!/system/bin/sh
# Remove only module config; reports in /sdcard are kept for the user
rm -f /data/adb/a205f_inventory.conf
rm -rf /data/local/tmp/ainv.* 2>/dev/null

#!/system/bin/sh
# Magisk installer hook (runs during flash)
SKIPUNZIP=0

MODEL=$(getprop ro.product.model)
SDK=$(getprop ro.build.version.sdk)

ui_print "- A205F A-to-Z App & Service Inventory v1.0.1"
ui_print "- Device: ${MODEL:-unknown} (SDK ${SDK:-?})"

case "$MODEL" in
  SM-A205*) ;;
  *) ui_print "! Module SM-A205F ke liye bana hai, phir bhi chalega (read-only hai)" ;;
esac

if [ "${SDK:-0}" -lt 26 ] 2>/dev/null; then
  ui_print "! Android 8+ recommended"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
for f in service.sh action.sh uninstall.sh bin/scan.sh system/bin/appinventory; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done

ui_print "- Ye module phone me kuch change nahi karta (sirf padhta hai)"
ui_print "- Reboot ke baad scan khud chalega (~1-3 min)"
ui_print "- Report: /sdcard/AppInventory_A205F/report/00_SUMMARY.txt"
ui_print "- Action button dabao: A-Z apps+services ki SINGLE file banegi:"
ui_print "-   /sdcard/Download/A205F_Inventory_AtoZ.txt"
ui_print "- Ya terminal se:  su -c \"appinventory --export\""

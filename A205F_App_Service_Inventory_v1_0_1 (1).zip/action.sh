#!/system/bin/sh
# Magisk "Action" button: scan chalao aur A-to-Z apps + services ki ek single file Download folder me save karo
MODDIR=${0%/*}
echo "- Scan shuru (1-3 min lagta hai)..."
sh "$MODDIR/bin/scan.sh" --no-notify --export

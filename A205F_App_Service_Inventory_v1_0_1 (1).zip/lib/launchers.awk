# Fallback: packages having a LAUNCHER activity, read from `dumpsys package` Activity Resolver Table
/^Activity Resolver Table:/ { on = 1; next }
/^[A-Za-z]/ { on = 0 }
on && /^ +[0-9a-f]+ [A-Za-z0-9_.]+\/[^ ]+ filter [0-9a-f]+/ { split($2, a, "/"); cur = a[1]; next }
on && /Category: "android.intent.category.LAUNCHER"/ { if (cur != "") print cur }

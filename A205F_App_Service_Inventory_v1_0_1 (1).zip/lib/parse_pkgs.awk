# Parse `dumpsys package` -> TSV, one row per package record (single pass)
# cols: pkg sect(P|H) uid vname vcode tsdk codepath installer flags first last u0inst u0hid u0susp u0stop u0en users
# Section H = "Hidden system packages" (original system copy of an updated system app)
# Per-user states (sect P only) are written to file UF: pkg user installed hidden suspended stopped enabled
function kv(s, k,   t) {
  t = " " s
  if (match(t, " " k "=[^ ]*")) return substr(t, RSTART + length(k) + 2, RLENGTH - length(k) - 2)
  return "-"
}
function val(s) { sub(/^[^=]*=/, "", s); return s }
function dash(s) { return (s == "" || s == "null") ? "-" : s }
function reset() { uid = vname = vcode = tsdk = cp = inst = fl = fi = lu = users = ""; u0i = u0h = u0s = u0st = u0e = "-" }
function flush(   f) {
  if (pkg == "") return
  f = ""
  if (index(fl, " SYSTEM "))            f = f "SYSTEM,"
  if (index(fl, "UPDATED_SYSTEM_APP"))  f = f "UPDATED,"
  if (index(fl, " PERSISTENT "))        f = f "PERSISTENT,"
  if (index(fl, "PRIVILEGED"))          f = f "PRIVILEGED,"
  if (index(fl, " DEBUGGABLE "))        f = f "DEBUGGABLE,"
  if (index(fl, " TEST_ONLY "))         f = f "TESTONLY,"
  sub(/,$/, "", f)
  print pkg, sect, dash(uid), dash(vname), dash(vcode), dash(tsdk), dash(cp), dash(inst), dash(f), dash(fi), dash(lu), u0i, u0h, u0s, u0st, u0e, dash(users)
  pkg = ""
}
BEGIN { OFS = "\t"; sect = ""; pkg = "" }
/^[A-Za-z]/ {
  flush()
  if ($0 ~ /^Packages:/) sect = "P"
  else if ($0 ~ /^Hidden system packages:/) sect = "H"
  else sect = ""
  next
}
sect == "" { next }
/^  Package \[/ {
  flush()
  pkg = $0; sub(/^  Package \[/, "", pkg); sub(/\].*/, "", pkg)
  reset()
  next
}
pkg == "" { next }
{
  line = $0; sub(/^ +/, "", line)
  if      (line ~ /^userId=/)               uid = val(line)
  else if (line ~ /^codePath=/)             cp = val(line)
  else if (line ~ /^versionCode=/) {
    tsdk = kv(line, "targetSdk"); if (tsdk == "-") tsdk = ""
    vcode = val(line); sub(/ .*/, "", vcode)
  }
  else if (line ~ /^versionName=/)          vname = val(line)
  else if (line ~ /^(pkgFlags|flags|privateFlags|privatePkgFlags)=/) fl = fl " " val(line) " "
  else if (line ~ /^firstInstallTime=/)     fi = val(line)
  else if (line ~ /^lastUpdateTime=/)       lu = val(line)
  else if (line ~ /^installerPackageName=/) inst = val(line)
  else if (line ~ /^User [0-9]+:/) {
    un = line; sub(/^User /, "", un); sub(/:.*/, "", un)
    ins = kv(line, "installed"); hid = kv(line, "hidden"); sus = kv(line, "suspended")
    stp = kv(line, "stopped");   en = kv(line, "enabled")
    if (ins == "true") users = users (users == "" ? "" : ",") un
    if (un == "0") { u0i = ins; u0h = hid; u0s = sus; u0st = stp; u0e = en }
    if (sect == "P" && UF != "") print pkg, un, ins, hid, sus, stp, en > UF
  }
}
END { flush() }

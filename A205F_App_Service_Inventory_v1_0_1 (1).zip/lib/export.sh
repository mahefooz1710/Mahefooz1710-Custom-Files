# shellcheck shell=sh
# Single-file export: A-to-Z apps + services ek hi .txt me (Download folder).
# READ-ONLY: report folder se padhta hai, nayi file sirf DL_DIR me likhta hai.

# exp_sec <title> <file> [1 = extra spaces squeeze karo (file chhoti rahe)]
exp_sec() {
  [ -f "$2" ] || return 0
  printf '\n\n######## %s ########\n' "$1"
  if [ "$3" = 1 ]; then sed 's/  */ /g' "$2"; else cat "$2"; fi
}

export_single() {
  SINGLE_OUT=""; SINGLE_SZ=0
  _R="$OUT_BASE/report"
  [ -d "$_R" ] || return 1
  _T="$W/single.txt"

  {
    echo "A205F A-to-Z APP & SERVICE INVENTORY  --  SINGLE FILE"
    echo "Generated : $(date '+%Y-%m-%d %H:%M:%S')"
    echo "Sections  : 1 SUMMARY | 2 ALL APPS A-Z | 3 ORPHAN APKs | 4 OTHER USERS | 5 APEX | 6 ALL SERVICES A-Z | 7 SPECIAL SERVICES"
    echo
    echo "HOW TO READ"
    echo " - Columns single space se alag hain."
    echo " - APPS    : A-Z key | package id | type | group | tags | version"
    echo "   type  = SYSTEM / USER / SYSTEM-REMOVED / USER-UNINSTALLED"
    echo "   tags  = UPDATED DISABLED HIDDEN SUSPENDED STOPPED OVERLAY NO-ICON PERSISTENT PRIV DEBUGGABLE SIDELOADED USERS:n  ('-' = koi tag nahi)"
    echo " - SERVICES: KIND | name | info   (KIND = BINDER / DUMPSYS / INIT / APP-RUNNING / APP-DECLARED)"
    echo " - System/user/disabled/hidden/removed/no-icon alag-alag list nahi hain: wo type + tags column se nikal jati hain."
    echo " - File ke end me 'END OF FILE' marker hona chahiye (warna file adhuri hai)."
  } > "$_T"

  exp_sec "1. SUMMARY"                                  "$_R/00_SUMMARY.txt"                                  >> "$_T"
  exp_sec "2. ALL APPS A-Z"                             "$_R/01_ALL_APPS_A-Z.txt" 1                           >> "$_T"
  exp_sec "3. ORPHAN APKs (disk par hai, PackageManager me nahi)" "$_R/09_ORPHAN_APKS_not_registered.txt"     >> "$_T"
  exp_sec "4. OTHER USERS / PROFILES"                   "$_R/10_OTHER_USERS_PROFILES.txt"                     >> "$_T"
  exp_sec "5. APEX MODULES"                             "$_R/11_APEX_MODULES.txt"                             >> "$_T"
  exp_sec "6. ALL SERVICES A-Z"                         "$_R/20_ALL_SERVICES_A-Z.txt" 1                       >> "$_T"
  exp_sec "7. SPECIAL SERVICES (accessibility / listeners / IME / admin)" "$_R/21_SPECIAL_SERVICES_accessibility_admin_ime.txt" >> "$_T"
  printf '\n\n######## END OF FILE ########\n' >> "$_T"

  if mkdir -p "$DL_DIR" 2>/dev/null && cp "$_T" "$DL_DIR/$DL_NAME" 2>/dev/null; then
    SINGLE_OUT="$DL_DIR/$DL_NAME"
  elif cp "$_T" "$OUT_BASE/$DL_NAME" 2>/dev/null; then
    SINGLE_OUT="$OUT_BASE/$DL_NAME"      # Download me likh nahi paya -> fallback
  else
    return 1
  fi
  chmod 0666 "$SINGLE_OUT" 2>/dev/null
  SINGLE_SZ=$(wc -c < "$SINGLE_OUT" | tr -d ' ')

  # file manager / Downloads app me turant dikhe (best-effort)
  if command -v am >/dev/null 2>&1; then
    tmo 10 am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://$SINGLE_OUT" >/dev/null 2>&1
  fi
  return 0
}

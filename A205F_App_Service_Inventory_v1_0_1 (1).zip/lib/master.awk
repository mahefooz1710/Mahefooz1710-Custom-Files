# Build classified master table (user 0 view).
# usage: awk -F'\t' -v R=<raw dir> -f short.awk -f master.awk pkgs_P.tsv
# out cols: key pkg type group tags version vcode uid installer path first last
function load(name, file,   l) {
  while ((getline l < file) > 0) if (l != "") S[name "|" l] = 1
  close(file)
}
function has(name, p) { return ((name "|" p) in S) }
function grp(p, usr) {
  if (p ~ /^(com\.samsung\.android\.knox|com\.samsung\.knox|com\.knox|com\.sec\.enterprise|com\.samsung\.android\.mdm)/) return "KNOX"
  if (p ~ /^(com\.qualcomm|com\.qti|com\.mediatek|com\.samsung\.slsi|org\.codeaurora|vendor\.)/) return "CHIPSET"
  if (p ~ /^(com\.samsung|com\.sec|com\.osp|com\.sem|com\.monotype|com\.diotek|com\.wssyncmldm|com\.wsomacp|com\.policydm|com\.mobeam|com\.dsi|com\.fmm|android\.samsung)/) return "SAMSUNG"
  if (p ~ /^(com\.google|com\.android\.vending|com\.android\.chrome|com\.android\.webview)/) return "GOOGLE"
  if (p ~ /^(android$|android\.|com\.android\.|org\.chromium|org\.simalliance)/) return "ANDROID-AOSP"
  if (p ~ /^(com\.facebook|com\.microsoft|com\.netflix|com\.spotify|com\.amazon|com\.linkedin|com\.touchtype|com\.opera|com\.ebay|com\.booking|com\.hiya|com\.dti|com\.aura|com\.digitalturbine|com\.ironsource|com\.zhiliaoapp|com\.zynga|com\.king|com\.gameloft)/) return "PARTNER-BLOAT"
  return usr ? "USER-APP" : "OTHER-SYSTEM"
}
{
  p = $1
  ver[p] = $4; vc[p] = $5; uid[p] = $3; cp[p] = $7; inst[p] = $8; fl[p] = $9
  fi[p] = $10; lu[p] = $11; u0i[p] = $12; u0h[p] = $13; u0s[p] = $14; u0st[p] = $15; u0e[p] = $16; us[p] = $17
}
END {
  OFS = "\t"
  load("system", R "/p_system.txt");   load("disabled", R "/p_disabled.txt")
  load("uninst", R "/p_uninstalled.txt"); load("launcher", R "/p_launcher.txt")
  load("hsys", R "/p_hidden_system_orig.txt")
  while ((getline l < (R "/p_paths.tsv")) > 0) { split(l, a, "\t"); pp[a[1]] = a[2] }
  close(R "/p_paths.tsv")
  while ((getline p < (R "/p_all.txt")) > 0) {
    if (p == "") continue
    sysf = has("system", p) || has("hsys", p) || (fl[p] ~ /SYSTEM/)
    typ = sysf ? "SYSTEM" : "USER"
    gone = has("uninst", p) || (u0i[p] == "false")
    if (gone) typ = sysf ? "SYSTEM-REMOVED" : "USER-UNINSTALLED"
    path = (cp[p] != "" && cp[p] != "-") ? cp[p] : ((p in pp) ? pp[p] : "-")
    ovl = (path ~ /\/overlay\// || p ~ /(\.overlay|\.rro|auto_generated_rro)/)
    t = ""
    if (fl[p] ~ /UPDATED/ || has("hsys", p)) t = t "UPDATED,"
    if (has("disabled", p) || u0e[p] ~ /^[234]$/) t = t "DISABLED,"
    if (u0h[p] == "true") t = t "HIDDEN,"
    if (u0s[p] == "true") t = t "SUSPENDED,"
    if (u0st[p] == "true") t = t "STOPPED,"
    if (ovl) t = t "OVERLAY,"
    else if (!gone && !has("launcher", p)) t = t "NO-ICON,"
    if (fl[p] ~ /PERSISTENT/) t = t "PERSISTENT,"
    if (fl[p] ~ /PRIVILEGED/) t = t "PRIV,"
    if (fl[p] ~ /DEBUGGABLE/) t = t "DEBUGGABLE,"
    if (typ == "USER" && (inst[p] == "" || inst[p] == "-")) t = t "SIDELOADED,"
    if (us[p] != "" && us[p] != "-" && us[p] != "0") t = t "USERS:" us[p] ","
    sub(/,$/, "", t); if (t == "") t = "-"
    print short(p), p, typ, grp(p, !sysf), t, (ver[p] == "" ? "-" : ver[p]), (vc[p] == "" ? "-" : vc[p]), (uid[p] == "" ? "-" : uid[p]), (inst[p] == "" ? "-" : inst[p]), path, (fi[p] == "" ? "-" : fi[p]), (lu[p] == "" ? "-" : lu[p])
  }
}

# shellcheck shell=sh
# Service collection (READ-ONLY)
sget() { tmo 15 settings get secure "$1" 2>/dev/null | tr -d '\r' | tr ':' '\n' | sed '/^null$/d;/^$/d'; }

collect_services() {
  S="$STG/services"

  # 1) Binder system services (service list)
  tmo 60 service list 2>/dev/null | tr -d '\r' \
    | sed -n "s/^[0-9]*[[:space:]]*\([^:]*\): \[\(.*\)\]\$/\1${TAB}\2/p" | sort -f -u > "$S/binder_services.tsv"

  # 2) dumpsys-registered services
  tmo 60 dumpsys -l 2>/dev/null | tr -d '\r' | sed -n 's/^  *//p' | sort -f -u > "$S/dumpsys_services.txt"

  # 3) init (native daemons): defined in *.rc  +  live state from init.svc.* props
  getprop 2>/dev/null | tr -d '\r' \
    | sed -n "s/^\[init\.svc\.\([^]]*\)\]: \[\(.*\)\]\$/\1${TAB}\2/p" | sort -f > "$W/init_state.tsv"
  : > "$W/rcfiles.txt"
  for _g in /init*.rc /system/etc/init/*.rc /system/etc/init/hw/*.rc /vendor/etc/init/*.rc /vendor/etc/init/hw/*.rc \
            /odm/etc/init/*.rc /odm/etc/init/hw/*.rc /product/etc/init/*.rc /system_ext/etc/init/*.rc; do
    for _f in $AIROOT$_g; do [ -f "$_f" ] && echo "$_f" >> "$W/rcfiles.txt"; done
  done
  : > "$W/rcdefs.tsv"
  if [ -s "$W/rcfiles.txt" ]; then
    # shellcheck disable=SC2046
    awk -v A="$AIROOT" 'FNR==1{f=FILENAME; sub("^" A,"",f)} $1=="service"{print $2 "\t" $3 "\t" f}' $(sort -u "$W/rcfiles.txt") > "$W/rcdefs.tsv"
  fi
  awk -F'\t' 'FILENAME==ARGV[1]{st[$1]=$2; next}
    { print $1 "\t" (($1 in st) ? st[$1] : "not-started") "\t" $2 "\t" $3; seen[$1]=1 }
    END { for (n in st) if (!(n in seen)) print n "\t" st[n] "\t-\t-" }' "$W/init_state.tsv" "$W/rcdefs.tsv" \
    | sort -f -u -t"$TAB" -k1,1 > "$S/init_services.tsv"

  # 4) app services running right now
  tmo 90 dumpsys activity services 2>/dev/null | tr -d '\r' | grep -o 'ServiceRecord{[^}]*}' \
    | sed -n "s/^ServiceRecord{[0-9a-f]* u\([0-9]*\) \([^ }]*\)[ }].*\$/\2${TAB}u\1/p" | sort -f -u > "$S/running_app_services.tsv"

  # 5) app services declared with an intent-filter (PackageManager resolver table)
  : > "$S/declared_app_services.tsv"
  if [ -s "$W/dump_package.txt" ]; then
    awk '/^Service Resolver Table:/{on=1;next} /^[A-Za-z]/{on=0}
      on && match($0, /[0-9a-f]+ [A-Za-z0-9_.]+\/[^ ]+ filter /) { split(substr($0, RSTART), a, " "); print a[2] }' \
      "$W/dump_package.txt" | sort -f -u | sed "s#/#${TAB}#" > "$S/declared_app_services.tsv"
  fi

  # 6) hidden-but-powerful: accessibility / notification listeners / IME / device admins
  {
    echo "## Accessibility services enabled";   sget enabled_accessibility_services
    echo; echo "## Notification listeners enabled"; sget enabled_notification_listeners
    echo; echo "## Input methods enabled";       sget enabled_input_methods
    echo; echo "## Device admins"
    tmo 30 dumpsys device_policy 2>/dev/null | tr -d '\r' | grep -o 'ComponentInfo{[^}]*}' | sort -u
  } > "$S/special_services.txt"
}

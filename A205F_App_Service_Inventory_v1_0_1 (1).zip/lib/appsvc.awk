# App-service rows keyed by owning app (so they sort A-Z by app, not by class name)
# usage: awk -F'\t' -v KIND=APP-RUNNING|APP-DECLARED -f short.awk -f appsvc.awk file
{
  if (KIND == "APP-DECLARED") { pkg = $1; name = $1 "/" $2; extra = "-" }
  else { split($1, a, "/"); pkg = a[1]; name = $1; extra = $2 }
  print short(pkg) "\t" KIND "\t" name "\t" extra
}

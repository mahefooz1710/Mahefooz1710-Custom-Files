# shellcheck shell=sh
# Common helpers (sourced by bin/scan.sh). READ-ONLY toolkit.
export LC_ALL=C
PATH="/data/adb/magisk:/data/adb/ksu/bin:/data/adb/ap/bin:$PATH:/system/bin:/system/xbin:/vendor/bin"
export PATH

# ---- prefer Magisk/KSU/APatch busybox applets for consistent behaviour ----
BB=""
for _b in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
  if [ -x "$_b" ]; then BB="$_b"; break; fi
done
if [ -n "$BB" ]; then
  _L=$("$BB" --list 2>/dev/null)
  for _c in awk sed grep sort comm cut tr find wc head tail uniq date mkdir cp mv rm cat ls basename dirname readlink nice timeout tee; do
    case "
$_L
" in
      *"
$_c
"*) eval "$_c() { \"$BB\" $_c \"\$@\"; }" ;;
    esac
  done
fi

for _t in awk sed grep sort comm cut tr find wc head; do
  command -v "$_t" >/dev/null 2>&1 || { echo "ERROR: '$_t' not found (Magisk busybox chahiye)"; exit 1; }
done

# ---- config (persisted outside module dir so updates keep it) ----
CONF="${AI_CONF:-/data/adb/a205f_inventory.conf}"
OUT_BASE=/sdcard/AppInventory_A205F
DL_DIR=/sdcard/Download                      # single-file export yahan save hoti hai
DL_NAME=A205F_Inventory_AtoZ.txt
RUN_ON_BOOT=1
BOOT_DELAY=60
STORAGE_WAIT=180
[ -f "$CONF" ] && . "$CONF"
[ -n "$AI_OUT" ] && OUT_BASE="$AI_OUT"      # test override
[ -n "$AI_DL" ] && DL_DIR="$AI_DL"          # test override
AIROOT="${AI_ROOT:-}"                        # test prefix for partitions
TMPBASE="${AI_TMP:-/data/local/tmp}"
LOCK="$TMPBASE/ainv.lock"
W=""; STG=""

ensure_conf() {
  [ -f "$CONF" ] && return 0
  cat 2>/dev/null > "$CONF" <<EOF
# A205F inventory module config (edit karke save karo)
RUN_ON_BOOT=1            # 1 = har boot par auto scan, 0 = sirf manual
BOOT_DELAY=60            # boot ke baad kitne second ruk kar scan shuru kare
OUT_BASE=/sdcard/AppInventory_A205F
DL_DIR=/sdcard/Download             # Action button wali single file yahan banegi
DL_NAME=A205F_Inventory_AtoZ.txt
EOF
}

say() {
  [ "$QUIET" = 1 ] || echo "$*"
  [ -n "$STG" ] && echo "$(date '+%H:%M:%S') $*" >> "$STG/scan.log" 2>/dev/null
  return 0
}

# tmo SECS cmd args...  (timeout guard so a hung dumpsys can't block forever)
tmo() {
  _s=$1; shift
  if command -v timeout >/dev/null 2>&1; then timeout "$_s" "$@"; else "$@"; fi
}

cnt() { if [ -s "$1" ]; then wc -l < "$1" | tr -d ' '; else echo 0; fi; }

wait_storage() {
  case "$OUT_BASE" in /sdcard/*|/storage/*) ;; *) return 0 ;; esac
  _i=0
  while [ ! -d /storage/emulated/0/Android ] && [ "$_i" -lt "$STORAGE_WAIT" ]; do
    sleep 2; _i=$((_i + 2))
  done
  [ -d /storage/emulated/0/Android ] || OUT_BASE="$TMPBASE/AppInventory_A205F"
}

setup_dirs() {
  W="$TMPBASE/ainv.$$"
  rm -rf "$W"; mkdir -p "$W" || { echo "ERROR: $W nahi ban sakta"; exit 1; }
  wait_storage
  STG="$OUT_BASE/.staging"
  rm -rf "$STG"
  if ! mkdir -p "$STG/raw" "$STG/services" 2>/dev/null; then
    OUT_BASE="$TMPBASE/AppInventory_A205F"; STG="$OUT_BASE/.staging"
    rm -rf "$STG"; mkdir -p "$STG/raw" "$STG/services" || { echo "ERROR: output dir nahi bani"; exit 1; }
  fi
}

lock_acquire() {
  if [ -d "$LOCK" ]; then
    _p=$(cat "$LOCK/pid" 2>/dev/null)
    if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then return 1; fi
    rm -rf "$LOCK"
  fi
  mkdir -p "$TMPBASE" 2>/dev/null
  mkdir "$LOCK" 2>/dev/null || return 1
  echo $$ > "$LOCK/pid"
}

cleanup() { [ -n "$W" ] && rm -rf "$W" 2>/dev/null; rm -rf "$LOCK" 2>/dev/null; }

# staging -> report ; previous report kept as report.prev
publish() {
  rm -rf "$OUT_BASE/report.prev"
  [ -d "$OUT_BASE/report" ] && mv "$OUT_BASE/report" "$OUT_BASE/report.prev"
  mv "$STG" "$OUT_BASE/report" || { echo "ERROR: publish fail"; exit 1; }
  chmod -R a+rX "$OUT_BASE" 2>/dev/null
  STG=""
}

notify_done() {
  command -v cmd >/dev/null 2>&1 || return 0
  tmo 15 cmd notification post -t "App Inventory ready" a205f_inventory \
    "Apps: $N_ALL | Services: $N_SVC_TOTAL | ${SINGLE_OUT:-$OUT_BASE/report}" >/dev/null 2>&1
  return 0
}

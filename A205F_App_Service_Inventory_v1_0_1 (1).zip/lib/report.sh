# shellcheck shell=sh
# Device info + A-to-Z report builders (READ-ONLY, writes only into staging dir)
gp() { getprop "$1" 2>/dev/null | tr -d '\r'; }

collect_device() {
  {
    echo "Model            : $(gp ro.product.model) ($(gp ro.product.device))"
    echo "Android          : $(gp ro.build.version.release) (SDK $(gp ro.build.version.sdk))"
    echo "Build            : $(gp ro.build.display.id)"
    echo "Security patch   : $(gp ro.build.version.security_patch)"
    echo "CSC sales code   : $(gp ro.csc.sales_code) $(gp ro.csc.country_code)"
    echo "Platform         : $(gp ro.board.platform) / $(gp ro.hardware)"
    echo "Kernel           : $(uname -r 2>/dev/null)"
    echo "SELinux          : $(getenforce 2>/dev/null)"
    echo "Magisk           : $(magisk -v 2>/dev/null || echo n/a)"
    echo "Scan time        : $(date '+%Y-%m-%d %H:%M:%S')   (uid $(id -u 2>/dev/null))"
  } > "$STG/device_info.txt"
}

# az_report <master-format tsv> <title>   (stdout)
az_report() {
  awk -F'\t' -v T="$2" '
    BEGIN { print "== " T " =="; print "A-Z key | package id | type | group | tags | version"; print "" }
    { l = toupper(substr($1, 1, 1)); if (l !~ /[A-Z]/) l = "#"
      if (l != last) { printf "\n[%s]\n", l; last = l }
      printf "  %-26s %-50s %-17s %-14s %-30s v%s\n", $1, $2, $3, $4, $5, $6 }' "$1"
}

# subset '<awk condition>' 'Title' outfile
subset() {
  awk -F'\t' "$1" "$W/master.tsv" > "$W/subset.tsv"
  { az_report "$W/subset.tsv" "$2"; echo; echo "TOTAL: $(cnt "$W/subset.tsv")"; } > "$STG/$3"
}

ncond() { awk -F'\t' "$1" "$W/master.tsv" | wc -l | tr -d ' '; }
row() { printf '  %-46s %s\n' "$1" "$2"; }

build_apps_reports() {
  R="$STG/raw"
  awk -F'\t' -v R="$R" -f "$LIB/short.awk" -f "$LIB/master.awk" "$R/pkgs_P.tsv" | sort -f -t"$TAB" -k1,1 -k2,2 > "$W/master.tsv"
  N_ALL=$(cnt "$W/master.tsv")

  # machine-readable CSV (open in Excel / Sheets)
  { echo 'package,type,group,tags,version,versionCode,uid,installer,path,firstInstall,lastUpdate,shortname'
    awk -F'\t' 'BEGIN { OFS = "," } { for (i = 1; i <= NF; i++) { gsub(/"/, "\"\"", $i); $i = "\"" $i "\"" }
      print $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $1 }' "$W/master.tsv"; } > "$STG/apps_master.csv"

  subset '1'                         "ALL APPS (system + user + hidden + removed)" 01_ALL_APPS_A-Z.txt
  subset '$3=="SYSTEM"'              "SYSTEM APPS (installed)"                      02_SYSTEM_APPS.txt
  subset '$3=="USER"'                "USER-INSTALLED APPS"                          03_USER_APPS.txt
  subset '$5 ~ /UPDATED/'            "UPDATED SYSTEM APPS (original copy hidden under /system)" 04_UPDATED_SYSTEM_APPS.txt
  subset '$5 ~ /DISABLED/'           "DISABLED APPS"                                05_DISABLED_APPS.txt
  subset '$3 ~ /REMOVED|UNINSTALLED/' "REMOVED / DEBLOATED (package still known, data kept)" 06_REMOVED_DEBLOATED.txt
  subset '$5 ~ /HIDDEN|SUSPENDED/'   "HIDDEN or SUSPENDED flag set"                 07_HIDDEN_OR_SUSPENDED.txt
  subset '$5 ~ /NO-ICON/'            "NO LAUNCHER ICON (invisible in app drawer)"   08_NO_LAUNCHER_ICON.txt

  { echo "== ORPHAN APKs: file disk par hai par PackageManager me registered NAHI =="
    echo "(CSC-disabled / stale / leftover / truly hidden APKs)"; echo
    sed 's/^/  /' "$R/apk_orphans.txt"; echo; echo "TOTAL: $(cnt "$R/apk_orphans.txt")"; } > "$STG/09_ORPHAN_APKS_not_registered.txt"
  N_ORPH=$(cnt "$R/apk_orphans.txt")

  { echo "== OTHER USERS / PROFILES (Secure Folder=150, Dual Messenger=95, work profile ...) =="; echo
    cat "$R/users.txt"; echo; echo "user<TAB>package"; cat "$R/other_users.tsv"; echo
    echo "TOTAL entries: $(cnt "$R/other_users.tsv")"; } > "$STG/10_OTHER_USERS_PROFILES.txt"

  { echo "== APEX modules (mainline) =="; echo; sed 's/^/  /' "$R/p_apex.txt"; echo; echo "TOTAL: $(cnt "$R/p_apex.txt")"; } > "$STG/11_APEX_MODULES.txt"

  PREV="$OUT_BASE/report/raw/p_all.txt"
  if [ -s "$PREV" ]; then
    { echo "== CHANGES since previous scan =="; echo; echo "-- NEW packages"; comm -13 "$PREV" "$R/p_all.txt" | sed 's/^/  + /'
      echo; echo "-- GONE packages"; comm -23 "$PREV" "$R/p_all.txt" | sed 's/^/  - /'; } > "$STG/12_CHANGES_since_last_scan.txt"
  else
    echo "Pehla scan hai - compare ke liye purana data nahi." > "$STG/12_CHANGES_since_last_scan.txt"
  fi

  # grouped view: SAMSUNG / GOOGLE / KNOX / PARTNER-BLOAT ...
  { echo "== APPS BY GROUP =="; sort -f -t"$TAB" -k4,4 -k1,1 "$W/master.tsv" \
      | awk -F'\t' '{ if ($4 != g) { printf "\n[%s]\n", $4; g = $4 } printf "  %-20s %-48s %-14s %s\n", $1, $2, $3, $5 }'; } > "$STG/13_BY_GROUP.txt"
}

build_services_reports() {
  S="$STG/services"
  { awk -F'\t' '{ print tolower($1) "\tBINDER\t" $1 "\t" $2 }' "$S/binder_services.tsv"
    awk '{ print tolower($0) "\tDUMPSYS\t" $0 "\t-" }' "$S/dumpsys_services.txt"
    awk -F'\t' '{ print tolower($1) "\tINIT\t" $1 "\t" $2 " | " $3 " | " $4 }' "$S/init_services.tsv"
    awk -F'\t' -v KIND=APP-RUNNING  -f "$LIB/short.awk" -f "$LIB/appsvc.awk" "$S/running_app_services.tsv"
    awk -F'\t' -v KIND=APP-DECLARED -f "$LIB/short.awk" -f "$LIB/appsvc.awk" "$S/declared_app_services.tsv"
  } | sort -f -t"$TAB" -k1,1 -k2,2 -k3,3 > "$W/svc_all.tsv"
  N_SVC_TOTAL=$(cnt "$W/svc_all.tsv")
  N_SVC_BINDER=$(cnt "$S/binder_services.tsv"); N_SVC_DUMPSYS=$(cnt "$S/dumpsys_services.txt")
  N_SVC_INIT=$(cnt "$S/init_services.tsv"); N_SVC_RUN=$(cnt "$S/running_app_services.tsv"); N_SVC_DECL=$(cnt "$S/declared_app_services.tsv")
  N_INIT_UP=$(awk -F'\t' '$2=="running"' "$S/init_services.tsv" | wc -l | tr -d ' ')

  { echo "== ALL SERVICES A-Z  (BINDER / DUMPSYS / INIT / APP-RUNNING / APP-DECLARED) =="; echo
    awk -F'\t' '{ l = toupper(substr($1, 1, 1)); if (l !~ /[A-Z]/) l = "#"
      if (l != last) { printf "\n[%s]\n", l; last = l }
      printf "  %-12s %-62s %s\n", $2, $3, $4 }' "$W/svc_all.tsv"
    echo; echo "TOTAL: $N_SVC_TOTAL"; } > "$STG/20_ALL_SERVICES_A-Z.txt"
  cp "$S/special_services.txt" "$STG/21_SPECIAL_SERVICES_accessibility_admin_ime.txt"
}

build_summary() {
  { echo "=================================================="
    echo " A205F  A-to-Z  APP & SERVICE INVENTORY"
    echo "=================================================="
    cat "$STG/device_info.txt"; echo
    echo "APPS (user 0 view)"
    row "Total packages known (incl. removed)" "$N_ALL"
    row "Installed right now"                  "$(cnt "$STG/raw/p_installed.txt")"
    row "System apps"                          "$(ncond '$3=="SYSTEM"')"
    row "User-installed apps"                  "$(ncond '$3=="USER"')"
    row "Updated system apps"                  "$(ncond '$5 ~ /UPDATED/')"
    row "Disabled"                             "$(ncond '$5 ~ /DISABLED/')"
    row "Removed/debloated (data kept)"        "$(ncond '$3 ~ /REMOVED|UNINSTALLED/')"
    row "HIDDEN/SUSPENDED flag"                "$(ncond '$5 ~ /HIDDEN|SUSPENDED/')"
    row "No launcher icon (background/hidden)" "$(ncond '$5 ~ /NO-ICON/')"
    row "Overlays (RRO themes)"                "$(ncond '$5 ~ /OVERLAY/')"
    row "Sideloaded (no installer)"            "$(ncond '$5 ~ /SIDELOADED/')"
    row "Orphan APKs (on disk, unregistered)"  "$N_ORPH"
    row "APEX modules"                         "$(cnt "$STG/raw/p_apex.txt")"
    row "App entries in other users"           "$(cnt "$STG/raw/other_users.tsv")"
    echo; echo "By group:"
    awk -F'\t' '{ c[$4]++ } END { for (g in c) printf "  %-20s %d\n", g, c[g] }' "$W/master.tsv" | sort
    echo; echo "SERVICES"
    row "Binder system services"               "$N_SVC_BINDER"
    row "dumpsys-registered services"          "$N_SVC_DUMPSYS"
    row "Init/native services (running/total)" "$N_INIT_UP / $N_SVC_INIT"
    row "App services running now"             "$N_SVC_RUN"
    row "App services declared (intent-filter)" "$N_SVC_DECL"
    row "TOTAL unique rows in A-Z list"        "$N_SVC_TOTAL"
    echo; echo "FILES: 01_ALL_APPS_A-Z  02_SYSTEM  03_USER  04_UPDATED  05_DISABLED  06_REMOVED"
    echo "       07_HIDDEN  08_NO_LAUNCHER_ICON  09_ORPHAN_APKS  10_OTHER_USERS  11_APEX"
    echo "       12_CHANGES  13_BY_GROUP  20_ALL_SERVICES_A-Z  21_SPECIAL_SERVICES"
    echo "       apps_master.csv (full table)   services/ (raw lists)   raw/ (source data)"
    echo; echo "NOTES"
    echo " - A-Z sorting package id ke meaningful hisse se (com./samsung./android. hata kar); real app label ke liye aapt chahiye."
    echo " - Launcher detection: $LAUNCH_SRC"
    echo " - NO-ICON = drawer me nahi dikhta (normal for services/overlays) - malicious hona zaruri nahi."
    echo " - Intent-filter ke bina declared services pm se visible nahi hoti (running list me aa jati hain)."
  } > "$STG/00_SUMMARY.txt"
}

build_reports() {
  if [ ! -s "$STG/raw/p_all.txt" ]; then
    say "WARNING: pm list khali aaya - root/shell access check karo"
  fi
  build_apps_reports
  build_services_reports
  build_summary
}

# short(pkg): readable A-Z sort key from a package id
#   com.samsung.android.bixby.agent -> bixby.agent ; com.sec.android.app.launcher -> launcher
function short(p,   n, a, i, s, st) {
  n = split(tolower(p), a, ".")
  st = 1
  if (n > 1 && a[1] ~ /^(com|org|net|io|in|co|de|me|app|android)$/) st = 2
  while (st < n && a[st] ~ /^(samsung|sec|android|app|apps|osp|google|qualcomm|qti|mediatek|codeaurora)$/) st++
  s = a[st]
  for (i = st + 1; i <= n; i++) s = s "." a[i]
  return s
}

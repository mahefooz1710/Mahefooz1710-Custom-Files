# shellcheck shell=sh
# App collection (READ-ONLY: only pm list / dumpsys / find)
TAB=$(printf '\t')

pm_list() { tmo 90 pm list packages "$@" 2>/dev/null | tr -d '\r' | sed 's/^package://' | sort -u; }

collect_apps() {
  R="$STG/raw"

  pm_list     > "$R/p_installed.txt"      # installed for user 0
  pm_list -u  > "$R/p_all.txt"            # + uninstalled-but-data-kept (debloated)
  pm_list -s  > "$R/p_system.txt"
  pm_list -3  > "$R/p_third.txt"
  pm_list -d  > "$R/p_disabled.txt"
  comm -13 "$R/p_installed.txt" "$R/p_all.txt" > "$R/p_uninstalled.txt"
  tmo 60 pm list packages --apex-only 2>/dev/null | tr -d '\r' | sed 's/^package://' | sort -u > "$R/p_apex.txt"
  tmo 90 pm list packages -f -u 2>/dev/null | tr -d '\r' \
    | sed -n "s#^package:\(.*\)=\([^= ]*\)\$#\2${TAB}\1#p" | sort -u > "$R/p_paths.tsv"
  tmo 30 pm list users 2>/dev/null | tr -d '\r' > "$R/users.txt"

  # one big dump, parsed once (version, flags, per-user hidden/suspended/enabled ...)
  say "    dumpsys package (bada hai, thoda time lagega)"
  tmo 240 dumpsys package > "$W/dump_package.txt" 2>/dev/null
  : > "$R/pkg_user_states.tsv"
  awk -v UF="$R/pkg_user_states.tsv" -f "$LIB/parse_pkgs.awk" "$W/dump_package.txt" > "$W/pkgs_all.tsv"
  awk -F'\t' '$2=="P"' "$W/pkgs_all.tsv" > "$R/pkgs_P.tsv"
  awk -F'\t' '$2=="H"{print $1}' "$W/pkgs_all.tsv" | sort -u > "$R/p_hidden_system_orig.txt"

  # packages that own a launcher icon (others = background/hidden-from-drawer)
  tmo 60 pm query-activities --brief -a android.intent.action.MAIN -c android.intent.category.LAUNCHER 2>/dev/null \
    | tr -d '\r' | grep -oE '[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+' | cut -d/ -f1 | sort -u > "$R/p_launcher.txt"
  LAUNCH_SRC="pm query-activities"
  if [ "$(cnt "$R/p_launcher.txt")" -lt 5 ]; then
    awk -f "$LIB/launchers.awk" "$W/dump_package.txt" | sort -u > "$R/p_launcher.txt"
    LAUNCH_SRC="dumpsys resolver table (fallback)"
  fi

  # APK files on disk that PackageManager does not know (truly hidden / stale / CSC-disabled)
  : > "$W/apk_found.txt"
  _dirs="/system/app /system/priv-app /system/framework /system/overlay /system/preload /system/hidden
    /product/app /product/priv-app /product/overlay /vendor/app /vendor/priv-app /vendor/overlay
    /odm/app /odm/priv-app /system_ext/app /system_ext/priv-app /optics /prism /preload /data/app"
  for _p in product system_ext vendor; do   # real dirs only (skip symlinks to avoid double scan)
    if [ -d "$AIROOT/system/$_p" ] && [ ! -L "$AIROOT/system/$_p" ]; then
      _dirs="$_dirs /system/$_p/app /system/$_p/priv-app /system/$_p/overlay"
    fi
  done
  for _d in $_dirs; do
    [ -d "$AIROOT$_d" ] && find "$AIROOT$_d" -maxdepth 4 -name '*.apk' 2>/dev/null >> "$W/apk_found.txt"
  done
  sed "s#^$AIROOT##" "$W/apk_found.txt" | sort -u > "$W/apk_found2.txt"
  { awk -F'\t' '$7!="-"{print $7}' "$W/pkgs_all.tsv"; awk -F'\t' '{print $2}' "$R/p_paths.tsv"; } | sort -u > "$W/codepaths.txt"
  awk -f "$LIB/orphans.awk" "$W/codepaths.txt" "$W/apk_found2.txt" | sort -u > "$R/apk_orphans.txt"

  # apps living in other users (Secure Folder = 150, Dual Messenger = 95, work profile ...)
  awk -F'\t' '$2!="0" && $3=="true"{print $2 "\t" $1}' "$R/pkg_user_states.tsv" \
    | sort -t"$TAB" -k1,1n -k2,2 > "$R/other_users.tsv"
}

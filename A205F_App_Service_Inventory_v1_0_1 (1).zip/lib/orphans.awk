# Print APK files that no registered package points to (stale / disabled-by-CSC / hidden APKs)
# usage: awk -f orphans.awk codepaths.txt apks.txt
function addcp(p) {
  sub(/\/+$/, "", p)
  if (p == "" || p == "-") return
  cp[p] = 1
  if (p ~ /^\/system\/(product|system_ext|vendor)\//) cp[substr(p, 8)] = 1
  else if (p ~ /^\/(product|system_ext|vendor)\//)    cp["/system" p] = 1
}
FILENAME == ARGV[1] { addcp($0); next }
{
  q = $0; ok = 0
  while (q != "" && q != "/") {
    if (q in cp) { ok = 1; break }
    sub(/\/[^\/]*$/, "", q)
  }
  if (!ok) print $0
}

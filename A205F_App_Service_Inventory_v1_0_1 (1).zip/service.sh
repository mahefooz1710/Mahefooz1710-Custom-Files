#!/system/bin/sh
# Boot par auto-scan (background me, boot slow nahi karta)
MODDIR=${0%/*}
(
  while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done

  RUN_ON_BOOT=1
  BOOT_DELAY=60
  [ -f /data/adb/a205f_inventory.conf ] && . /data/adb/a205f_inventory.conf
  [ "$RUN_ON_BOOT" = "1" ] || exit 0

  sleep "$BOOT_DELAY"
  if command -v nice >/dev/null 2>&1; then
    nice -n 15 sh "$MODDIR/bin/scan.sh" --quiet >/dev/null 2>&1
  else
    sh "$MODDIR/bin/scan.sh" --quiet >/dev/null 2>&1
  fi
) &
